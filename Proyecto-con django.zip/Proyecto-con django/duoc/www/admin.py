from django.contrib import admin

# Register your models here.
from .models import Genero, Alumno

admin.site.register(Genero)
admin.site.register(Alumno)